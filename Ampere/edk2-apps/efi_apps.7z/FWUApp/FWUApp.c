/**
 *
 * Ampere FW Update Utility Application
 *
 * Copyright (c) 2018-2020, Ampere Computing Inc. All rights reserved.
 *
 * This program and the accompanying materials
 * are licensed and made available under the terms and conditions of the BSD
 * License which accompanies this distribution. The full text of the license
 * may be found at http://opensource.org/licenses/bsd-license.php
 *
 * THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
 * WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.
 *
 * This application can be used from UEFI shell to register the firmware upgrade
 * verification key with ATF and perform signed firmware updates/upgrades on
 * Ampere SoC's.
 **/

#include <Uefi.h>
#include <Library/DebugLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/UefiApplicationEntryPoint.h>
#include <Library/UefiLib.h>
#include <Library/PrintLib.h>
#include <Protocol/ShellParameters.h>
#include <Protocol/Shell.h>
#include <Library/ArmSMCSecureLib.h>
#include <Library/ArmLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/ArmSmcLib.h>
#include <Library/ShellLib.h>

#include <Protocol/MmCommunication.h>

EFI_MM_COMMUNICATION_PROTOCOL       *gMmCommunication = NULL;

#define EFI_MM_MAX_PAYLOAD_U64_E    10
#define EFI_MM_MAX_PAYLOAD_SIZE     (EFI_MM_MAX_PAYLOAD_U64_E * sizeof(UINT64))

/* FWU MM GUID */
EFI_GUID gFwuMmGuid = (EFI_GUID)
{ 0x452240CD, 0xB3B3, 0x4695, { 0x9A, 0x63, 0xDF, 0xEC, 0x50, 0x82, 0xE7, 0x7A } };

typedef struct {
  /* Allows for disambiguation of the message format */
  EFI_GUID HeaderGuid;
  /*
   * Describes the size of Data (in bytes) and does not include the size
   * of the header
   */
  UINTN MsgLength;
} EFI_MM_COMM_HEADER_NOPAYLOAD;

typedef struct {
  UINT64 Data[EFI_MM_MAX_PAYLOAD_U64_E];
} EFI_MM_COMM_SECVAR_PAYLOAD;

typedef struct {
  EFI_MM_COMM_HEADER_NOPAYLOAD EfiMmHdr;
  EFI_MM_COMM_SECVAR_PAYLOAD   PayLoad;
} EFI_MM_COMM_REQUEST;

typedef struct {
  UINT64 Status;
  UINT64 Progress;
} EFI_MM_COMMUNICATE_FWU_RES;

enum {
  MM_FWU_SERVICE_IMG_ID_SCP = 1,
  MM_FWU_SERVICE_IMG_ID_ATFUEFI,
  MM_FWU_SERVICE_IMG_ID_CFGUEFI,
  MM_FWU_SERVICE_IMG_ID_UEFI,
};

#define FWU_MM_RES_SUCCESS              0xAABBCC00
#define FWU_MM_RES_IN_PROGRESS          0xAABBCC01
#define FWU_MM_RES_SECURITY_VIOLATION   0xAABBCC02
#define FWU_MM_RES_OUT_OF_RESOURCES     0xAABBCC03
#define FWU_MM_RES_IO_ERROR             0xAABBCC04
#define FWU_MM_RES_FAIL                 0xAABBCCFF

EFI_MM_COMM_REQUEST gEfiMmFwuReq;

STATIC EFI_MM_COMM_REQUEST *UefiMmCreateFwuReq(
    VOID *Data, UINT64 Size)
{
  CopyGuid (&gEfiMmFwuReq.EfiMmHdr.HeaderGuid, &gFwuMmGuid);
  gEfiMmFwuReq.EfiMmHdr.MsgLength = Size;

  if (Size != 0)
  {
    if (!Data)
    {
      DEBUG((DEBUG_ERROR, "Can't create UEFI MM request!\n"));
      return NULL;
    }
    if (Size > EFI_MM_MAX_PAYLOAD_SIZE)
    {
      DEBUG((DEBUG_ERROR, "Oversize payload!\n"));
      return NULL;
    }
    CopyMem (&gEfiMmFwuReq.PayLoad.Data, Data, Size);
  }

  return &gEfiMmFwuReq;
}

#define FWU_SERVICE_IMG_ID_SCP        1
#define FWU_SERVICE_IMG_ID_ATFUEFI    2
#define FWU_SERVICE_IMG_ID_CFGUEFI    3
#define FWU_SERVICE_IMG_ID_UEFI       4

#define AMPERE_CERT_VENDOR_GUID \
  {0x4796d3b0, 0x1bbb, 0x4680, {0xb4, 0x71, 0xa4, 0x9b, 0x49, 0xb2, 0x39, 0x0e}}

typedef struct {
  VOID *AtfUefiFwuImg;
  UINTN AtfUefiFwuImgSize;
  VOID *CfgUefiFwuImg;
  UINTN CfgUefiFwuImgSize;
  VOID *UefiFwuImg;
  UINTN UefiFwuImgSize;
  VOID *SCPFwuImg;
  UINTN SCPFwuImgSize;
  VOID *DBUCert;
  UINTN DBUCertSize;
  VOID *DBBCert;
  UINTN DBBCertSize;
} COMMAND_LINE_OPTIONS;

STATIC UINTN  mArgCount;
STATIC CHAR16 **mArgVector;
STATIC EFI_SHELL_PROTOCOL      *mShellProtocol = NULL;
STATIC EFI_GUID mAmpereCertVarGuid = AMPERE_CERT_VENDOR_GUID;

/**

  This function parse application ARG.

  @return Status
**/
STATIC EFI_STATUS
GetArg (
    IN EFI_HANDLE        ImageHandle,
    IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  EFI_STATUS                    Status;
  EFI_SHELL_PARAMETERS_PROTOCOL *ShellParameters;

  if (!ImageHandle || !SystemTable) {
    return EFI_INVALID_PARAMETER;
  }

  if (!gEfiShellParametersProtocol) {
    Status = SystemTable->BootServices->OpenProtocol(ImageHandle,
                              &gEfiShellParametersProtocolGuid,
                              (VOID **) &gEfiShellParametersProtocol,
                              ImageHandle,
                              NULL,
                              EFI_OPEN_PROTOCOL_GET_PROTOCOL
                            );
    if (EFI_ERROR(Status)) {
      return Status;
    }
  }

  mArgCount = gEfiShellParametersProtocol->Argc;
  mArgVector = gEfiShellParametersProtocol->Argv;

  return EFI_SUCCESS;
}

/**
  Get shell protocol.

  @return Pointer to shell protocol.
**/
STATIC EFI_SHELL_PROTOCOL *
GetShellProtocol (
  VOID
  )
{
  EFI_STATUS            Status;

  if (mShellProtocol == NULL) {
    Status = gBS->LocateProtocol (
                    &gEfiShellProtocolGuid,
                    NULL,
                    (VOID **) &mShellProtocol
                    );
    if (EFI_ERROR (Status)) {
      mShellProtocol = NULL;
    }
  }

  return mShellProtocol;
}

/**
  Read a file.

  @param[in]  FileName        The file to be read.
  @param[out] BufferSize      The file buffer size
  @param[out] Buffer          The file buffer

  @retval EFI_SUCCESS    Read file successfully
  @retval EFI_NOT_FOUND  Shell protocol or file not found
  @retval others         Read file failed
**/
STATIC EFI_STATUS
ReadFileToBuffer (
  IN  CHAR16                               *FileName,
  OUT UINTN                                *BufferSize,
  OUT VOID                                 **Buffer
  )
{
  EFI_STATUS                        Status;
  EFI_SHELL_PROTOCOL                *ShellProtocol;
  SHELL_FILE_HANDLE                 Handle;
  UINT64                            FileSize;
  UINTN                             TempBufferSize;
  VOID                              *TempBuffer;

  ShellProtocol = GetShellProtocol();
  if (ShellProtocol == NULL) {
    return EFI_NOT_FOUND;
  }

  //
  // Open file by FileName.
  //
  Status = ShellProtocol->OpenFileByName (
                            FileName,
                            &Handle,
                            EFI_FILE_MODE_READ
                            );
  if (EFI_ERROR (Status)) {
    return Status;
  }

  //
  // Get the file size.
  //
  Status = ShellProtocol->GetFileSize (Handle, &FileSize);
  if (EFI_ERROR (Status)) {
    ShellProtocol->CloseFile (Handle);
    return Status;
  }

  TempBufferSize = (UINTN) FileSize;
  TempBuffer = AllocateZeroPool (TempBufferSize);
  if (TempBuffer == NULL) {
    ShellProtocol->CloseFile (Handle);
    return EFI_OUT_OF_RESOURCES;
  }

  //
  // Read the file data to the buffer
  //
  Status = ShellProtocol->ReadFile (
                            Handle,
                            &TempBufferSize,
                            TempBuffer
                            );
  if (EFI_ERROR (Status)) {
    ShellProtocol->CloseFile (Handle);
    FreePool(TempBuffer);
    return Status;
  }

  ShellProtocol->CloseFile (Handle);

  *BufferSize = TempBufferSize;
  *Buffer     = TempBuffer;

  return EFI_SUCCESS;
}

STATIC EFI_STATUS DoFWU(
  UINTN ImageId,
  VOID *Data,
  UINTN Len
)
{
  EFI_MM_COMM_REQUEST *EfiMmCommFwuReq;
  EFI_MM_COMMUNICATE_FWU_RES *MmFwuStatus;
  EFI_STATUS Status;
  UINT64 MmData[5];
  UINTN Size;

  if (!gMmCommunication)
  {
    Status = gBS->LocateProtocol(
        &gEfiMmCommunicationProtocolGuid,
        NULL,
        (VOID **)&gMmCommunication);
    if (EFI_ERROR(Status))
    {
      Print(L"%a: Can't locate gEfiMmCommunicationProtocolGuid\n", __FUNCTION__);
      return Status;
    }
  }

  MmData[0] = ImageId;
  MmData[1] = Len;
  MmData[2] = (UINT64)Data;
  MmData[3] = 1; // MM yield for progress reporting.
  Print(L"DoFWU ID %d Len %d Data %p\n", ImageId, Len, Data);

  while (1)
  {
    EfiMmCommFwuReq = UefiMmCreateFwuReq((void *)&MmData, sizeof(MmData));
    if (!EfiMmCommFwuReq)
    {
      return -1;
    }

    Size = sizeof(EFI_MM_COMM_HEADER_NOPAYLOAD) + sizeof(MmData);
    Status = gMmCommunication->Communicate(NULL, EfiMmCommFwuReq, &Size);
    if (EFI_ERROR(Status))
    {
      Print(L"FWU: MM communication error %x\n", Status);
      return -1;
    }

    /* Return data in the first double word of payload */
    MmFwuStatus = (EFI_MM_COMMUNICATE_FWU_RES *) EfiMmCommFwuReq->PayLoad.Data;
    if (MmFwuStatus->Status == FWU_MM_RES_IN_PROGRESS)
    {
      Print(L"..");
      continue;
    }
    break;
  }

  if (MmFwuStatus->Status != FWU_MM_RES_SUCCESS)
  {
    if (MmFwuStatus->Status == FWU_MM_RES_SECURITY_VIOLATION)
    {
      Print(L"FWU: Failed update."
          " Security Violation. \n");
      return EFI_SECURITY_VIOLATION;
    }

    if (MmFwuStatus->Status == FWU_MM_RES_OUT_OF_RESOURCES)
    {
      Print(L"FWU: Failed update."
                " Insufficient resources.\n");
      return EFI_OUT_OF_RESOURCES;
    }

    if (MmFwuStatus->Status == FWU_MM_RES_IO_ERROR)
    {
      Print(L"FWU: Failed update."
                " IO Error.\n");
      return EFI_DEVICE_ERROR;
    }

    Print(L"FWU: Failed update."
              " Unknown Error %d.\n", MmFwuStatus->Status);
    return EFI_DEVICE_ERROR;
  }

  return EFI_SUCCESS;
}

/**
  Print APP usage.
**/
STATIC CHAR16 *
PrintUsage (
  VOID
  )
{
  CHAR16 *Str;

  Str = CatSPrint(NULL, L"Supported command...\r\n"
                        "Ampere Firmware Update Usage:\n"
                        " -K <UpdateDBUPubCertFile>\n"
                        " -P <UpdateDBBPubCertFile>\n"
                        " -S <SignedScpFirmwareFile>\n"
                        " -A <SignedAtfUefiFirmwareFile>\n"
                        " -C <SignedCfgUefiFirmwareFile>\n"
                        " -U <SignedUefiFirmwareFile>\n"
                        "Parameter:\n"
                        "  -K: Register the Public Key Certificate to be used for firmware\n"
                        "      update verification. This must be an x509 certificate.\n"
                        "      The file provided must be the authorization file (.auth)\n"
                        "       to register or delete the DBU certificate..\n"
                        "  -P: Register the Public Key Certificate to be used for firmware\n"
                        "      verification. This must be an x509 certificate.\n"
                        "      The file provided must be the authorization file (.auth)\n"
                        "       to register or delete the DBB certificate..\n"
                        "  -S: Update SCP firmware."
                        " The signed SCP firmware file to be used for the update"
                        " must be provided.\n"
                        "  -A: Update ATF/UEFI firmware. The signed firmware file to be used"
                        " for the update must be provided.\n"
                        "  -C: Update board config plus UEFI firmware. The signed firmware file to be used"
                        " for the update must be provided.\n"
                        "  -U: Update only UEFI firmware. The signed firmware file to be used"
                        " for the update must be provided.\n"
                        );

  return Str;
}

/**
  Get the help string of 'FWU' command.

  @retval String A Null-terminated Unicode string.
  @retval NULL if not enough resource.
**/
CHAR16 *FWUAppGetHelpString (VOID)
{
  return PrintUsage ();
}

STATIC EFI_STATUS
ParseCommandLineArgs(
    UINTN  Argc,
    CHAR16 **Argv,
    COMMAND_LINE_OPTIONS *Options
)
{

  UINTN       Index;
  EFI_STATUS  Status;
  CHAR16      *Str;

  if (!Options) {
    return EFI_INVALID_PARAMETER;
  }

  if (Argc < 2) {
    Str = PrintUsage();
    Print(L"%s", Str);
    FreePool ((VOID *) Str);
    return EFI_UNSUPPORTED;
  }

  for (Index = 1; Index < Argc; Index++) {
    if (!StrCmp(Argv[Index], L"-K")) {
      Index++;

      if (Index >= Argc) {
        Print(L"Invalid parameter count.\n");
        return EFI_INVALID_PARAMETER;
      }

      Print(L"Reading DBU Cert.\n");

      Status = ReadFileToBuffer(Argv[Index], &(Options->DBUCertSize),
          &(Options->DBUCert));
      if (EFI_ERROR (Status)) {
        Print(L"Failed to read DBU Cert\n");
        return Status;
      }
    } else if (!StrCmp(Argv[Index], L"-P")) {
      Index++;

      if (Index >= Argc) {
        Print(L"Invalid parameter count.\n");
        return EFI_INVALID_PARAMETER;
      }

      Print(L"Reading DBB Cert.\n");

      Status = ReadFileToBuffer(Argv[Index], &(Options->DBBCertSize),
          &(Options->DBBCert));
      if (EFI_ERROR (Status)) {
        Print(L"Failed to read DBB Cert\n");
        return Status;
      }
    } else if (!StrCmp(Argv[Index], L"-S")) {
      Index++;

      if (Index >= Argc) {
        Print(L"Invalid parameter count.\n");
        return EFI_INVALID_PARAMETER;
      }

      Print(L"Reading SCP FW update image.\n");

      Status = ReadFileToBuffer(Argv[Index], &(Options->SCPFwuImgSize),
          &(Options->SCPFwuImg));
      if (EFI_ERROR (Status)) {
        Print(L"Failed to SCP FW update image.\n");
        return Status;
      }
    } else if (!StrCmp(Argv[Index], L"-A")) {
      Index++;

      if (Index >= Argc) {
        Print(L"Invalid parameter count.\n");
        return EFI_INVALID_PARAMETER;
      }

      Print(L"Reading ATF/UEFI FW update image.\n");

      Status = ReadFileToBuffer(Argv[Index], &(Options->AtfUefiFwuImgSize),
          &(Options->AtfUefiFwuImg));
      if (EFI_ERROR (Status)) {
        Print(L"Failed to read ATF/UEFI FW update image\n");
        return Status;
      }
    } else if (!StrCmp(Argv[Index], L"-C")) {
      Index++;

      if (Index >= Argc) {
        Print(L"Invalid parameter count.\n");
        return EFI_INVALID_PARAMETER;
      }

      Print(L"Reading board config plus UEFI FW update image.\n");

      Status = ReadFileToBuffer(Argv[Index], &(Options->CfgUefiFwuImgSize),
          &(Options->CfgUefiFwuImg));
      if (EFI_ERROR (Status)) {
        Print(L"Failed to read board config plus UEFI FW update image\n");
        return Status;
      }
    } else if (!StrCmp(Argv[Index], L"-U")) {
      Index++;

      if (Index >= Argc) {
        Print(L"Invalid parameter count.\n");
        return EFI_INVALID_PARAMETER;
      }

      Print(L"Reading UEFI FW update image.\n");

      Status = ReadFileToBuffer(Argv[Index], &(Options->UefiFwuImgSize),
          &(Options->UefiFwuImg));
      if (EFI_ERROR (Status)) {
        Print(L"Failed to read UEFI FW update image\n");
        return Status;
      }
    }
  }

  return EFI_SUCCESS;

}

EFI_STATUS
FWUCheckVariableExists (IN CHAR16 *Name)
{
  EFI_STATUS  Status;
  UINTN       DataSize = 0;
  UINT32      Attributes;

  Print(L"Getting %s Cert Variable\n", Name);
  Status = gRT->GetVariable(Name,
      &mAmpereCertVarGuid,
      &Attributes, &DataSize,
      NULL);
  if (Status != EFI_BUFFER_TOO_SMALL) {
    return EFI_NOT_FOUND;
  } else if (DataSize != 0) {
    Print(L"Found Current %s Cert. Size = %d bytes\n", Name, DataSize);
    Status = EFI_SUCCESS;
  } else {
    Print(L"Internal error. %s cert exists but has size 0."
        " Status = 0x%x %d\n", Name, Status);
  }

  return Status;
}

/**
  The user Entry Point for Application. The user code starts with this function
  as the real entry point for the application.

  @param[in] ImageHandle    The firmware allocated handle for the EFI image.
  @param[in] SystemTable    A pointer to the EFI System Table.

  @retval EFI_SUCCESS       The entry point is executed successfully.
  @retval other             Some error occurs when executing this entry point.

**/
EFI_STATUS
EFIAPI
FWUAppEntryPoint(
    IN EFI_HANDLE        ImageHandle,
    IN EFI_SYSTEM_TABLE  *SystemTable
)
{
  EFI_STATUS Status;
  COMMAND_LINE_OPTIONS Options = { 0 };
  UINT32 Attributes;

  Print(L"Ampere Firmware Update Utility.\n");

  Status = GetArg (ImageHandle, SystemTable);
  if (EFI_ERROR(Status)) {
    Print(L"Please use UEFI SHELL to run this application!\n", Status);
    return Status;
  }

  Status = ParseCommandLineArgs(mArgCount, mArgVector, &Options);
  if (EFI_ERROR(Status)) {
    Print(L"Failed to parse command line args.!\n", Status);
    goto Exit;
  }

  if (Options.DBUCertSize) {
    Print(L"Attempting to Write DBU certificate.\n");

    Attributes = EFI_VARIABLE_NON_VOLATILE
        | EFI_VARIABLE_RUNTIME_ACCESS
        | EFI_VARIABLE_BOOTSERVICE_ACCESS
        | EFI_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS;

    Status = gRT->SetVariable(
        L"dbu",
        &mAmpereCertVarGuid,
        Attributes,
        Options.DBUCertSize,
        Options.DBUCert
        );
    if (EFI_ERROR(Status)) {
      Print(L"Failed to write new data to DBU Cert variable"
          " Status = 0x%x.\n", Status);
      goto Exit;
    }
    Status = FWUCheckVariableExists (L"dbu");
    if (EFI_ERROR (Status)) {
      Print(L"DBU Cert was deleted succesfully\n");
    }
  }

  if (Options.DBBCertSize) {
    Print(L"Attempting to Write DBB certificate.\n");

    Attributes = EFI_VARIABLE_NON_VOLATILE
        | EFI_VARIABLE_RUNTIME_ACCESS
        | EFI_VARIABLE_BOOTSERVICE_ACCESS
        | EFI_VARIABLE_TIME_BASED_AUTHENTICATED_WRITE_ACCESS;

    Status = gRT->SetVariable(
        L"dbb",
        &mAmpereCertVarGuid,
        Attributes,
        Options.DBBCertSize,
        Options.DBBCert
        );
    if (EFI_ERROR(Status)) {
      Print(L"Failed to write new data to DBB Cert variable"
          " Status = 0x%x.\n", Status);
      goto Exit;
    }
    Status = FWUCheckVariableExists (L"dbb");
    if (EFI_ERROR (Status)) {
      Print(L"DBB Cert was deleted succesfully\n");
    }
  }

  if (Options.SCPFwuImgSize) {
    Status = FWUCheckVariableExists (L"dbu");
    if (EFI_ERROR (Status)) {
      Print(L"Failed to get DBU Cert. Cancelling updating SCP FW\n");
      goto Exit;
    }

    Print(L"Updating SCP FW...\n");
    Status = DoFWU(FWU_SERVICE_IMG_ID_SCP,
        Options.SCPFwuImg,
        Options.SCPFwuImgSize);
    if (EFI_ERROR(Status)) {
      Print(L"Failed to update SCP."
          " 0x%x\n", Status);
      goto Exit;
    }
    Print(L"\nSCP FW update successful.\n");
  }

  if (Options.AtfUefiFwuImgSize) {
    Status = FWUCheckVariableExists (L"dbu");
    if (EFI_ERROR (Status)) {
      Print(L"Failed to get DBU Cert. Cancelling updating ATF/UEFI FW\n");
      goto Exit;
    }

    Print(L"Updating ATF/UEFI FW...\n");
    Status = DoFWU(FWU_SERVICE_IMG_ID_ATFUEFI,
        Options.AtfUefiFwuImg,
        Options.AtfUefiFwuImgSize);
    if (EFI_ERROR(Status)) {
      Print(L"Failed to update ATF/UEFI."
          " 0x%x\n", Status);
      goto Exit;
    }
    Print(L"\nATF/UEFI FW update successful.\n");
  }

  if (Options.CfgUefiFwuImgSize) {
    Status = FWUCheckVariableExists (L"dbu");
    if (EFI_ERROR (Status)) {
      Print(L"Failed to get DBU Cert. Cancelling updating board config plus UEFI FW\n");
      goto Exit;
    }

    Print(L"Updating board config plus UEFI FW...\n");
    Status = DoFWU(FWU_SERVICE_IMG_ID_CFGUEFI,
        Options.CfgUefiFwuImg,
        Options.CfgUefiFwuImgSize);
    if (EFI_ERROR(Status)) {
      Print(L"Failed to update board config plus UEFI."
          " 0x%x\n", Status);
      goto Exit;
    }
    Print(L"\nBoard config plus UEFI FW update successful.\n");
  }

  if (Options.UefiFwuImgSize) {
    Status = FWUCheckVariableExists (L"dbu");
    if (EFI_ERROR (Status)) {
      Print(L"Failed to get DBU Cert. Cancelling updating EFI FW\n");
      goto Exit;
    }

    Print(L"Updating EFI FW...\n");
    Status = DoFWU(FWU_SERVICE_IMG_ID_UEFI,
        Options.UefiFwuImg,
        Options.UefiFwuImgSize);
    if (EFI_ERROR(Status)) {
      Print(L"Failed to update UEFI."
          " 0x%x\n", Status);
      goto Exit;
    }
    Print(L"\nUEFI FW update successful.\n");
  }

  Status = EFI_SUCCESS;

Exit:

  if (Options.DBUCert) {
    FreePool(Options.DBUCert);
  }

  if (Options.DBBCert) {
    FreePool(Options.DBBCert);
  }

  if (Options.AtfUefiFwuImg) {
    FreePool(Options.AtfUefiFwuImg);
  }

  if (Options.CfgUefiFwuImg) {
    FreePool(Options.CfgUefiFwuImg);
  }

  if (Options.UefiFwuImg) {
    FreePool(Options.UefiFwuImg);
  }

  if (Options.SCPFwuImg) {
    FreePool(Options.SCPFwuImg);
  }

  return Status;
}
