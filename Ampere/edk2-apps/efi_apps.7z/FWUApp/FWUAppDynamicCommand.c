 /**
 *
 * Copyright (c) 2020, Ampere Computing LLC
 *
 *  This program and the accompanying materials
 *  are licensed and made available under the terms and conditions of the BSD License
 *  which accompanies this distribution.  The full text of the license may be found at
 *  http://opensource.org/licenses/bsd-license.php
 *
 *  THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.
 *
 **/

#include "FWUApp.h"
#include <Protocol/ShellDynamicCommand.h>

/**
  This is the shell command handler function pointer callback type.  This
  function handles the command when it is invoked in the shell.

  @param[in] This                   The instance of the EFI_SHELL_DYNAMIC_COMMAND_PROTOCOL.
  @param[in] SystemTable            The pointer to the system table.
  @param[in] ShellParameters        The parameters associated with the command.
  @param[in] Shell                  The instance of the shell protocol used in the context
                                    of processing this command.

  @return EFI_SUCCESS               the operation was sucessful
  @return other                     the operation failed.
**/
SHELL_STATUS
EFIAPI
FWUAppCommandHandler (
  IN EFI_SHELL_DYNAMIC_COMMAND_PROTOCOL    *This,
  IN EFI_SYSTEM_TABLE                      *SystemTable,
  IN EFI_SHELL_PARAMETERS_PROTOCOL         *ShellParameters,
  IN EFI_SHELL_PROTOCOL                    *Shell
  )
{
  gEfiShellParametersProtocol = ShellParameters;
  gEfiShellProtocol           = Shell;

  return FWUAppEntryPoint (gImageHandle, SystemTable);
}

/**
  This is the command help handler function pointer callback type.  This
  function is responsible for displaying help information for the associated
  command.

  @param[in] This                   The instance of the EFI_SHELL_DYNAMIC_COMMAND_PROTOCOL.
  @param[in] Language               The pointer to the language string to use.

  @return string                    Pool allocated help string, must be freed by caller
**/
CHAR16 *
EFIAPI
FWUAppCommandGetHelp (
  IN EFI_SHELL_DYNAMIC_COMMAND_PROTOCOL    *This,
  IN CONST CHAR8                           *Language
  )
{
  CHAR16 *Str, *Str1;

  Str = FWUAppGetHelpString ();
  Str1 = CatSPrint (NULL, L".TH fwu 0 \"Set authenticated variables / Upgrade firmware.\"\r\n"
                          ".SH NAME\r\n"
                          "Set authenticated variables / Upgrade firmware.\r\n"
                          ".SH SYNOPSIS\r\n"
                          "\r\n%s", Str);
  FreePool (Str);

  return Str1;
}

EFI_SHELL_DYNAMIC_COMMAND_PROTOCOL mFWUAppDynamicCommand = {
  L"fwu",
  FWUAppCommandHandler,
  FWUAppCommandGetHelp
};

/**
  Entry point of FWUApp Dynamic Command.
  Produce the DynamicCommand protocol to handle "FWUApp" command.

  @param  ImageHandle            The image handle of the process.
  @param  SystemTable            The EFI System Table pointer.

  @retval EFI_SUCCESS           FWUApp command is executed sucessfully.
  @retval EFI_ABORTED           HII package was failed to initialize.
  @retval others                Other errors when executing FWUApp command.
**/
EFI_STATUS
EFIAPI
FWUAppCommandInitialize (
  IN EFI_HANDLE               ImageHandle,
  IN EFI_SYSTEM_TABLE         *SystemTable
  )
{
  EFI_STATUS                  Status;

  Status = gBS->InstallProtocolInterface (
                  &ImageHandle,
                  &gEfiShellDynamicCommandProtocolGuid,
                  EFI_NATIVE_INTERFACE,
                  &mFWUAppDynamicCommand
                  );
  ASSERT_EFI_ERROR (Status);
  return Status;
}

/**
  FWUApp driver unload handler.

  @param  ImageHandle           The image handle of the process.

  @retval EFI_SUCCESS           The image is unloaded.
  @retval Others                Failed to unload the image.
**/
EFI_STATUS
EFIAPI
FWUAppUnload (
  IN EFI_HANDLE               ImageHandle
)
{
  EFI_STATUS                  Status;
  Status = gBS->UninstallProtocolInterface (
                  ImageHandle,
                  &gEfiShellDynamicCommandProtocolGuid,
                  &mFWUAppDynamicCommand
                  );
  if (EFI_ERROR (Status)) {
    return Status;
  }

  return EFI_SUCCESS;
}