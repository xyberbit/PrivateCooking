 /**
 *
 * Copyright (c) 2018, Ampere Computing LLC
 *
 *  This program and the accompanying materials
 *  are licensed and made available under the terms and conditions of the BSD License
 *  which accompanies this distribution.  The full text of the license may be found at
 *  http://opensource.org/licenses/bsd-license.php
 *
 *  THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.
 *
 **/

#include <AmiDxeLib.h>
#include <Protocol/SimpleFileSystem.h>
#include <Protocol/DevicePath.h>
#include <Protocol/LoadedImage.h>
#include <Library/DevicePathLib.h>
#include <Library/BdsLib.h>
#include <Setup.h>
#include <libfdt.h>
#include <Token.h>

extern  EFI_BOOT_SERVICES   *pBS;

EFI_STATUS
PrepareUEFI (
  IN     CONST CHAR8*         CommandLineString,
  IN     UINTN                KernelImageSize,
  IN     EFI_PHYSICAL_ADDRESS InitrdImage,
  IN     UINTN                InitrdImageSize)
{
  EFI_STATUS                  Status;
  EFI_PHYSICAL_ADDRESS        InitrdImageStart;
  EFI_PHYSICAL_ADDRESS        InitrdImageEnd;
  EFI_PHYSICAL_ADDRESS        BlobBase;
  CHAR8                       StdOutPath[64];
  UINTN                       UartParity = 0;
  VOID                        *Fdt;
  UINTN                       FdtSize;
  INTN                        Node;
  INTN                        Err;

  //64K is enough for fdt wrapper
  FdtSize = 64 * 1024;

  Status = pBS->AllocatePages (AllocateAnyPages, EfiBootServicesData,
                  EFI_SIZE_TO_PAGES (FdtSize), &BlobBase);
  if (EFI_ERROR (Status)) {
    Print (L"Failed to allocate Fdt address\n");
    return Status;
  }

  Fdt = (VOID *) BlobBase;
  if (fdt_create_empty_tree (Fdt, FdtSize)) {
    Print (L"Failed to create Fdt\n");
    Status = EFI_NOT_FOUND;
    goto Exit;
  }

  Node = fdt_add_subnode (Fdt, 0, "chosen");
  if (Node < 0) {
    Print (L"Error on finding 'chosen' node\n");
    Status = EFI_INVALID_PARAMETER;
    goto Exit;
  }

  //
  // Set Linux CmdLine
  //
  if ((CommandLineString != NULL) && (AsciiStrLen (CommandLineString) > 0)) {
    Err = fdt_setprop (Fdt, Node, "bootargs", CommandLineString, AsciiStrSize (CommandLineString));
    if (Err) {
      Print (L"Fail to set new 'bootarg' (error: %d)\n", Err);
      Status = EFI_INVALID_PARAMETER;
      goto Exit;
    }
  }

  //
  // Set Linux Initrd
  //
  if (InitrdImageSize != 0) {
    InitrdImageStart = cpu_to_fdt64 (InitrdImage);
    Err = fdt_setprop (Fdt, Node, "linux,initrd-start", &InitrdImageStart, sizeof(EFI_PHYSICAL_ADDRESS));
    if (Err) {
      Print (L"Fail to set new 'linux,initrd-start' (error: %d)\n", Err);
      Status = EFI_INVALID_PARAMETER;
      goto Exit;
    }

    InitrdImageEnd = cpu_to_fdt64 (InitrdImage + InitrdImageSize);
    Err = fdt_setprop(Fdt, Node, "linux,initrd-end", &InitrdImageEnd, sizeof(EFI_PHYSICAL_ADDRESS));
    if (Err) {
      Print (L"Fail to set new 'linux,initrd-start' (error: %d)\n", Err);
      Status = EFI_INVALID_PARAMETER;
      goto Exit;
    }
  }

  // Set stdout-path default to Tianocore boot console
  UartParity = UART_CONSOLE_DEFAULT_PARITY;
  AsciiSPrint (StdOutPath, sizeof (StdOutPath), "/soc/serial@%08x:%d%c%d\0",
                UART_CONSOLE_REGISTER_BASE,
                UART_CONSOLE_DEFAULT_BAUDRATE,
                UartParity == EvenParity ? 'e' : UartParity == OddParity ? 'o' : 'n',
                UART_CONSOLE_DEFAULT_DATABITS
              );

  Err = fdt_setprop (Fdt, Node, "linux,stdout-path", StdOutPath, AsciiStrSize (StdOutPath));
  if (Err) {
    Print (L"Fail to set new 'linux,stdout-path' (error: %d)\n", Err);
  }
  // Latest kernel to use stdout-path instead of linux,stdout-path
  Err = fdt_setprop (Fdt, Node, "stdout-path",  StdOutPath, AsciiStrSize (StdOutPath));
  if (Err) {
    Print (L"Fail to set new 'stdout-path' (error: %d)\n", Err);
  }

  Status = pBS->InstallConfigurationTable (&gFdtTableGuid, (void *) Fdt);
  if (EFI_ERROR (Status)) {
    Print (L"Fail to install FDT configuration table\n");
    goto Exit;
  }

  Status = EFI_SUCCESS;

Exit:
  pBS->FreePages (BlobBase, EFI_SIZE_TO_PAGES (FdtSize));

  return Status;
}

/**
  Start a Linux kernel from a Device Path

  @param  LinuxKernel           Device Path to the Linux Kernel
  @param  Initrd                Device Path to the Initrd
  @param  Parameters            Linux kernel agruments

  @retval EFI_SUCCESS           All drivers have been connected
  @retval EFI_NOT_FOUND         The Linux kernel Device Path has not been found
  @retval EFI_OUT_OF_RESOURCES  There is not enough resource memory to store the matching results.

**/
EFI_STATUS
BootLinuxUEFI (
  IN  EFI_HANDLE                ParentImageHandle,
  IN  EFI_DEVICE_PATH_PROTOCOL* LinuxKernelDevicePath,
  IN  EFI_DEVICE_PATH_PROTOCOL* InitrdDevicePath,
  IN  CONST CHAR8*              Arguments)
{
  EFI_STATUS                   Status;
  EFI_HANDLE                   ImageHandle;
  EFI_PHYSICAL_ADDRESS         LinuxImage;
  UINTN                        LinuxImageSize;
  EFI_PHYSICAL_ADDRESS         InitrdImage = 0;
  UINTN                        InitrdImageSize = 0;

  // Load the Linux kernel from a device path
  LinuxImage = 0;
  Print (L"Loading Linux image ");
  Status = BdsLoadImage (LinuxKernelDevicePath, AllocateAnyPages, &LinuxImage, &LinuxImageSize);
  if (EFI_ERROR (Status)) {
    Print (L"ERROR: Did not find Linux kernel.\n");
    return Status;
  }
  Print (L"at 0x%16LX Size %d bytes\n", LinuxImage, LinuxImageSize);

  if (InitrdDevicePath) {
    // Load the init ramdisk from a device path
    InitrdImage = 0;
    Print (L"Loading initrd ");
    Status = BdsLoadImage (InitrdDevicePath, AllocateAnyPages, &InitrdImage, &InitrdImageSize);
    if (EFI_ERROR (Status)) {
      Print (L"ERROR: Did not find initrd image.\n");
      return Status;
    }

    Print (L"at 0x%16LX Size %d bytes\n", InitrdImage, InitrdImageSize);
  }

  Status = PrepareUEFI (Arguments, LinuxImageSize,
                        InitrdImage, InitrdImageSize);
  if (EFI_ERROR (Status)) {
    Print (L"ERROR: Can not setup Linux ACPI . Status=0x%X\n", Status);
    return Status;
  }

  Print (L"\nLoaded: LinuxImage    = 0x%16LX, Size = %d bytes\n", LinuxImage, LinuxImageSize );
  Print (L"Loaded: Init RAM-disk = 0x%16LX, Size = %d bytes\n\n", InitrdImage, InitrdImageSize );
  
  // Load the image from the Buffer with Boot Services function
  Status = pBS->LoadImage (TRUE, ParentImageHandle, NULL, (VOID*)(UINTN) LinuxImage, LinuxImageSize, &ImageHandle);
  if (EFI_ERROR (Status)) {
    return Status;
  }

  // Before calling the image, enable the Watchdog Timer for  the 5 Minute period
  pBS->SetWatchdogTimer (5 * 60, 0x0000, 0x00, NULL);
  // Start the image
  Status = pBS->StartImage (ImageHandle, NULL, NULL);
  // Clear the Watchdog Timer after the image returns
  pBS->SetWatchdogTimer (0x0000, 0x0000, 0x0000, NULL);
  
  return Status;
}

/**
  The user Entry Point for Application. The user code starts with this function
  as the real entry point for the application.

  @param[in] ImageHandle    The firmware allocated handle for the EFI image.
  @param[in] SystemTable    A pointer to the EFI System Table.

  @retval EFI_SUCCESS       The entry point is executed successfully.
  @retval other             Some error occurs when executing this entry point.

**/

EFI_STATUS
EFIAPI
LinuxLoaderAppEntryPoint (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{

  EFI_STATUS                          Status;
  EFI_LOADED_IMAGE_PROTOCOL*          LoadedImage;
  EFI_DEVICE_PATH_PROTOCOL*           DevicePath = NULL;
  EFI_DEVICE_PATH_PROTOCOL*           KernelDevicePath= NULL;
  EFI_DEVICE_PATH_PROTOCOL*           RamDiskDevicePath= NULL;
  CHAR16*                             KernelDevicePathText;
  CHAR16*                             RamDiskDevicePathText;

  Print (L"=============================================================================\n");
  Print (L"                       Linux   Loader  Application                           \n");
  Print (L"=============================================================================\n");

  InitAmiLib (ImageHandle,SystemTable);

  Status = SystemTable->BootServices->HandleProtocol (ImageHandle,
                                  &gEfiLoadedImageProtocolGuid, (VOID**) &LoadedImage);
  
  if (EFI_ERROR (Status)) {
    return Status;
  }
  
  Status = SystemTable->BootServices->HandleProtocol (LoadedImage->DeviceHandle, 
                              &gEfiDevicePathProtocolGuid, (VOID**) &DevicePath);
  if (EFI_ERROR (Status)) {
    return Status;
  }
  

  Print (L"Booting Linux ACPI from  Memory Mapped device paths...... \r\n");
  KernelDevicePath = ConvertTextToDevicePath ((CHAR16*) LINUX_LOADER_BOOT_DEVICE_PATH);
  KernelDevicePathText = ConvertDevicePathToText (KernelDevicePath, TRUE, FALSE);
  Print (L"Kernel device path: %s \n", KernelDevicePathText);

  RamDiskDevicePath = ConvertTextToDevicePath ((CHAR16*) LINUX_LOADER_BOOT_INITRD_PATH);
  RamDiskDevicePathText = ConvertDevicePathToText (RamDiskDevicePath, TRUE, FALSE);
  Print (L"Ramdisk device path: %s \n", RamDiskDevicePathText);

  Status = BootLinuxUEFI (ImageHandle,
               KernelDevicePath,
               RamDiskDevicePath, // Initrd
               (CHAR8*) LINUX_LOADER_BOOT_ARGUMENT);
  Print (L"Error: failed to boot Linux : %r\n", Status);

  return Status;
}
