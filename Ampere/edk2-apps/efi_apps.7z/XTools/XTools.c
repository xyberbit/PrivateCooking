 /**
 *
 * Copyright (c) 2018-2020, Ampere Computing LLC
 *
 *  This program and the accompanying materials
 *  are licensed and made available under the terms and conditions of the BSD License
 *  which accompanies this distribution.  The full text of the license may be found at
 *  http://opensource.org/licenses/bsd-license.php
 *
 *  THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.
 *
 **/

#include <Library/BaseLib.h>
#include <Library/ArmLib.h>
#include <Library/ArmSmcLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/IoLib.h>
#include <Library/UefiLib.h>
#include <Library/UefiApplicationEntryPoint.h>
#include <Library/NVParamLib.h>
#include <Library/I2CProxyLib.h>
#include <Library/PrintLib.h>
#include <Library/ShellLib.h>
#include <Protocol/EfiShellParameters.h>
#include "KeyInput.h"

typedef struct __CMD_ENTRY CMD_ENTRY;

struct __CMD_ENTRY {
  CHAR16 *Cmd;
  INTN (*Func)(CMD_ENTRY *CmdEntry, CHAR16 *CmdInput);
  CHAR16 *Desc;
};

STATIC CHAR16 CmdBuffer[256];
STATIC CMD_ENTRY CommandTable[];

/**
  Check if a Unicode character is a decimal character.

  This internal function checks if a Unicode character is a
  decimal character. The valid decimal character is from
  L'0' to L'9'.

  @param  Char  The character to check against.

  @retval TRUE  If the Char is a decmial character.
  @retval FALSE If the Char is not a decmial character.

**/
STATIC BOOLEAN EFIAPI InternalIsDecimalDigitCharacter(IN CHAR16 Char)
{
  return (BOOLEAN) (Char >= L'0' && Char <= L'9');
}

/**
  Convert a Unicode character to lower case only if
  it maps to a valid small-case ASCII character.

  This internal function only deal with Unicode character
  which maps to a valid small-case ASCII character, i.e.
  L'A' to L'Z'. For other Unicode character, the input character
  is returned directly.

  @param  Char  The character to convert.

  @retval LowerCharacter   If the Char is with range L'A' to L'Z'.
  @retval Unchanged        Otherwise.

**/
STATIC CHAR16 EFIAPI InternalCharToLower(IN CHAR16 Char)
{
  if (Char >= L'A' && Char <= L'Z') {
    return (CHAR16) (Char + (L'a' - L'A'));
  }

  return Char;
}

STATIC INTN XTHelp(CMD_ENTRY *CmdEntry, CHAR16 *CmdInput)
{
  INTN Loop;

  Print(L"Supported command...\r\n");
  for (Loop = 0; CommandTable[Loop].Cmd != NULL; Loop++) {
    Print(L"%s - %s\r\n", CommandTable[Loop].Cmd, CommandTable[Loop].Desc);
  }
  return EFI_SUCCESS;
}

/**
  Get the help string of 'XTools' command.

  @retval String A Null-terminated Unicode string.
  @retval NULL if not enough resource.
**/
CHAR16 *XToolsGetHelpString (VOID)
{
  INTN Loop;
  CHAR16 *Str = NULL, *Str1 = NULL;

  Str = CatSPrint (Str, L"Supported command...\r\n");
  if  (!Str) {
    return Str;
  }

  for (Loop = 0; CommandTable[Loop].Cmd != NULL; Loop++) {
    Str = CatSPrint (Str1, L"%s - %s\r\n", CommandTable[Loop].Cmd, CommandTable[Loop].Desc);
    if  (!Str) {
      return Str;
    }
    if (Str1) {
      FreePool (Str1);
    }
    Str1 = Str;
  }

  return Str;
}

STATIC CHAR16 *XTPrompt(VOID)
{
  EFI_STATUS Status;

  Print(L"Enter command: ");

  ZeroMem(CmdBuffer, sizeof(CmdBuffer));
  Status = GetHIInputStr(CmdBuffer, sizeof(CmdBuffer)/sizeof(CmdBuffer[0]));
  if (EFI_ERROR(Status)) {
    return NULL;
  }
  return CmdBuffer;
}

STATIC CMD_ENTRY *XTGetCmdEntry(CHAR16 *CmdInput)
{
  INTN Loop;
  INTN CmdLen;

  for (Loop = 0; CommandTable[Loop].Cmd != NULL; Loop++) {
    CmdLen = StrLen(CommandTable[Loop].Cmd);
    if (StrnCmp(CmdInput, CommandTable[Loop].Cmd, CmdLen) == 0) {
      /*
       * Check for space or end of string. Please note that command
       * may not be null terminated as it can carry parameter(s).
       */
      if (CmdInput[CmdLen] == L'\0' || CmdInput[CmdLen] == L' ') {
        return &CommandTable[Loop];
      }
    }
  }
  return NULL;
}

STATIC CHAR16 * XTParseArg(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
)
{
  EFI_STATUS                    Status;
  CHAR16                        *BufPtr;
  INTN                          Loop;
  INTN                          BufLen;

  if (ImageHandle && !gEfiShellParametersProtocol) {
    Status = SystemTable->BootServices->OpenProtocol(ImageHandle,
                             &gEfiShellParametersProtocolGuid,
                             (VOID **) &gEfiShellParametersProtocol,
                             ImageHandle,
                             NULL,
                             EFI_OPEN_PROTOCOL_GET_PROTOCOL
                            );
  if (EFI_ERROR(Status)) {
      return NULL; /* No argument as not launch from shell */
    }
  }

  /* Get the argument */
  ZeroMem(CmdBuffer, sizeof(CmdBuffer));
  BufPtr = CmdBuffer;
  BufLen = sizeof(CmdBuffer)/sizeof(CmdBuffer[0]) - 1;

  for (Loop = 1; Loop < gEfiShellParametersProtocol->Argc &&
                 BufLen > 0; Loop++) {
    if (Loop != 1) {
      StrnCpy(BufPtr, L" ", BufLen);
      BufLen -= 1;
      BufPtr++;
    }
    if (BufLen > 0) {
      StrnCpy(BufPtr, gEfiShellParametersProtocol->Argv[Loop], BufLen);
      if (StrLen(gEfiShellParametersProtocol->Argv[Loop]) <= BufLen) {
        BufLen -= StrLen(gEfiShellParametersProtocol->Argv[Loop]);
        BufPtr += StrLen(gEfiShellParametersProtocol->Argv[Loop]);
      } else {
        BufPtr += BufLen;
        BufLen = 0;
      }
    }
  }
  *BufPtr = L'\0';
  return CmdBuffer;
}

STATIC VOID XTStr2LowerCase(CHAR16 *CmdStr)
{
  INTN Len;
  INTN Loop;

  Len = StrLen(CmdStr);
  for (Loop = 0; Loop < Len; Loop++) {
    CmdStr[Loop] = InternalCharToLower(CmdStr[Loop]);
  }
}

/**
  The user Entry Point for Application. The user code starts with this function
  as the real entry point for the application.

  @param[in] ImageHandle    The firmware allocated handle for the EFI image.
  @param[in] SystemTable    A pointer to the EFI System Table.

  @retval EFI_SUCCESS       The entry point is executed successfully.
  @retval other             Some error occurs when executing this entry point.

**/
EFI_STATUS
EFIAPI
XToolsEntryPoint(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  )
{
  CMD_ENTRY *CmdEntry;
  CHAR16    *CmdStr;
  BOOLEAN    Interactive = FALSE;

  CmdStr = XTParseArg(ImageHandle, SystemTable);
  if (!CmdStr) {
    Print(L"Ampere Tools v0.1\r\n");
    Interactive = TRUE;
  }

  do {
    if (Interactive) {
      CmdStr = XTPrompt();
      if (CmdStr == NULL) {
        break;
      }
      Print(L"\r\n");

      if (StrLen(CmdStr) == 0) {
        continue;
      }
    }

    /* Convert input string to lower case */
    XTStr2LowerCase(CmdStr);

    CmdEntry = XTGetCmdEntry(CmdStr);
    if (CmdEntry == NULL) {
      Print(L"Un-supported command %s. ? for help\r\n", CmdStr);
      if (Interactive) {
        continue;
      }
      break;
    }
    if (CmdEntry->Func == NULL) {
      break;
    }
    /* Remove command identify itself */
    CmdStr += StrLen(CmdEntry->Cmd);
    CmdEntry->Func(CmdEntry, CmdStr);
  } while (Interactive);

  return EFI_SUCCESS;
}

STATIC INTN XTGetINTN(CHAR16 *Str)
{
  INTN Value;

  if (*Str == L'-') {
    Value = StrDecimalToUintn(++Str);
    Value *= -1;
  } else {
    Value = StrDecimalToUintn(Str);
  }
  return Value;
}

STATIC INTN XTCSR(CMD_ENTRY *CmdEntry, CHAR16 *CmdInput)
{
  UINT32  CSRAddr;
  UINT32  Value;
  CHAR16  *Tmp;
  INTN    Res;
  BOOLEAN OpRd = TRUE;

  Tmp  = StrStr(CmdInput, L" ");
  if (Tmp == NULL) {
     Print(L"Invalid argument\r\n");
     return EFI_INVALID_PARAMETER;
  }
  CSRAddr = (UINT32) StrHexToUintn(++Tmp);

  Tmp  = StrStr(Tmp, L" ");
  if (Tmp == NULL) {
    Print(L"Invalid argument\r\n");
    return EFI_INVALID_PARAMETER;
  }
  if (StrnCmp(++Tmp, L"wr", 2) == 0) {
    OpRd = FALSE;

    Tmp  = StrStr(Tmp, L" ");
    if (Tmp == NULL) {
      Print(L"Invalid argument\r\n");
      return EFI_INVALID_PARAMETER;
    }
    Value = (UINT32) StrHexToUintn(++Tmp);
  }

  if (OpRd) {
    Value = MmioRead32(CSRAddr);
  } else {
    MmioWrite32(CSRAddr, Value);
  }
  Print(L"CSR 0x%08X Value: 0x%08X\r\n", CSRAddr, Value);
  return EFI_SUCCESS;
}

/**
  Convert a Unicode character to upper case only if
  it maps to a valid small-case ASCII character.

  This internal function only deal with Unicode character
  which maps to a valid small-case ASCII character, i.e.
  L'a' to L'z'. For other Unicode character, the input character
  is returned directly.

  @param  Char  The character to convert.

  @retval LowerCharacter   If the Char is with range L'a' to L'z'.
  @retval Unchanged        Otherwise.

**/
STATIC CHAR16
CharToUpper (
  IN      CHAR16                    Char
  )
{
  if (Char >= L'a' && Char <= L'z') {
    return (CHAR16) (Char - (L'a' - L'A'));
  }

  return Char;
}

/**
  Convert a Unicode character to numerical value.

  This internal function only deal with Unicode character
  which maps to a valid hexadecimal ASII character, i.e.
  L'0' to L'9', L'a' to L'f' or L'A' to L'F'. For other
  Unicode character, the value returned does not make sense.

  @param  Char  The character to convert.

  @return The numerical value converted.

**/
STATIC UINTN InternalHexCharToUintn(IN CHAR16 Char)
{
  if (InternalIsDecimalDigitCharacter (Char)) {
    return Char - L'0';
  }

  return (UINTN) (10 + CharToUpper (Char) - L'A');
}

STATIC INTN XTStrHex2Byte(CHAR16 *Data, INTN Len)
{
  if (Len < 2) {
    return -1;
  }

  return (InternalHexCharToUintn(Data[0]) << 4) |
         InternalHexCharToUintn(Data[1]);
}

STATIC INTN XTStrHex2ByteArray(CHAR16 *Input, UINT8 *Data, INTN Len)
{
  INTN DataLen = 0;
  INTN Value;

  if (Input[0] != L'0' || Input[1] != L'x') {
    return 0;
  }
  Input += 2;

  while (Input[0] != L'\0' && Len > 0) {
    Value = XTStrHex2Byte(Input, Len);
    if (Value == -1) {
      return DataLen;
    }
    *Data = ((UINT32) Value) & 0xFF;

    Input += 2;
    Data += 1;
    Len -= 1;
    DataLen++;
  }
  return DataLen;
}

STATIC INTN XTI2CProxy(CMD_ENTRY *CmdEntry, CHAR16 *CmdInput)
{
  UINT32  Bus;
  UINT32  Device;
  UINT32  Offset;
  UINT32  Proto;
  BOOLEAN OpRd = TRUE;
  UINT32  Len;
  UINT8   Data[256];
  CHAR16  *Tmp;
  INTN    Res;
  INTN    Loop;

  /* Get bus number (decimal) */
  Tmp  = StrStr(CmdInput, L" ");
  if (Tmp == NULL) {
    Print(L"Invalid argument - bus\r\n");
    return EFI_INVALID_PARAMETER;
  }
  Bus = (UINT32) StrDecimalToUintn(++Tmp);

  /* Get device address (hex) */
  Tmp  = StrStr(Tmp, L" ");
  if (Tmp == NULL) {
    Print(L"Invalid argument - device\r\n");
    return EFI_INVALID_PARAMETER;
  }
  Device = (UINT32) StrHexToUintn(++Tmp);

  /* Get the device offset address (hex) for the operation */
  Tmp  = StrStr(Tmp, L" ");
  if (Tmp == NULL) {
    Print(L"Invalid argument - offset\r\n");
    return EFI_INVALID_PARAMETER;
  }
  Offset = (UINT32) StrHexToUintn(++Tmp);

  /* Get protocol */
  Tmp  = StrStr(Tmp, L" ");
  if (Tmp == NULL) {
    Print(L"Invalid argument - protocol\r\n");
    return EFI_INVALID_PARAMETER;
  }
  Proto = (UINT32) StrDecimalToUintn(++Tmp);

  /* Operation */
  Tmp  = StrStr(Tmp, L" ");
  if (Tmp == NULL) {
    Print(L"Invalid argument - operation type\r\n");
    return EFI_INVALID_PARAMETER;
  }
  ++Tmp;
  if (StrnCmp(Tmp, L"wr ", 3) == 0) {
    OpRd = FALSE;

    Tmp  = StrStr(Tmp, L" ");
    if (Tmp == NULL) {
      Print(L"Invalid argument - value\r\n");
      return EFI_INVALID_PARAMETER;
    }
    /* Convert the hex string to data bytes */
    Len = XTStrHex2ByteArray(++Tmp, Data, 256);
    if (Len <= 0) {
      Print(L"Invalid argument - value\r\n");
      return EFI_INVALID_PARAMETER;
    }
  } else if (StrnCmp(Tmp, L"rd ", 3) == 0) {
    Tmp  = StrStr(Tmp, L" ");
    if (Tmp == NULL) {
      Print(L"Invalid argument - length\r\n");
      return EFI_INVALID_PARAMETER;
    }
    Len = (UINT32) StrDecimalToUintn(++Tmp);
    if (Len <= 0) {
      Print(L"Invalid argument - length\r\n");
      return EFI_INVALID_PARAMETER;
    }
  } else {
      Print(L"Invalid argument - operation\r\n");
      return EFI_INVALID_PARAMETER;
  }

  Res = I2CProxy(Bus, Device, OpRd ? I2CPROXY_RD : I2CPROXY_WR,
                  Proto == 1 ? I2CPROTO_SMB : I2CPROTO_I2C,
                  Offset >= 256 ? 2 : 1, Offset, &Len, Data);
  if (Res != 0) {
    Print(L"I2C operation failed with error %d\r\n", Res);
    return Res;
  }
  if (OpRd) {
    Print(L"0x");
    for (Loop = 0; Loop < Len; Loop++) {
      Print(L"%02X", Data[Loop]);
    }
    Print(L"\r\n");
  }
  return EFI_SUCCESS;
}

STATIC INTN XTParseU32(CHAR16 *CmdInput, UINT32 *val)
{
  CHAR16 *Tmp;
  INTN Len = 0;

  /* Get parameter address (decimal) */
  Tmp  = StrStr(CmdInput, L" 0x");
  if (Tmp == NULL) {
    Tmp = StrStr(CmdInput, L" ");
    if (Tmp == NULL) {
      return EFI_INVALID_PARAMETER;
    }
    Len += 1;
    ++Tmp;
    *val = (UINT32) StrDecimalToUintn(Tmp);
  } else {
    Len += 3;
    Tmp += 3;
    *val = (UINT32) StrHexToUintn(Tmp);
  }
  while (*Tmp != L'\0' && *Tmp != L' ') {
    ++Tmp;
    ++Len;
  }
  return Len;
}

STATIC VOID XTNVP_LISTALL(VOID)
{
  UINT32 NVAddr = 0;
  UINT32 NVVal;
  INTN   Res;

  Print(L"Listing all non volatile variables:\r\n");

  /* Iterate through the address range */
  for (NVAddr = 0; NVAddr < NV_PARAM_MAX_SIZE; NVAddr += 8) {
      /* Read request */
      Res = NVParamGet(NVAddr, NV_PERM_ALL, &NVVal);
      switch (Res) {
      case EFI_NOT_FOUND:
      case EFI_INVALID_PARAMETER:
      case EFI_UNSUPPORTED:
      case EFI_ACCESS_DENIED:
        continue;
      }
      Print(L"0x%08X: 0x%08X\r\n", NVAddr, NVVal);
  }
}

STATIC INTN XTNVP(CMD_ENTRY *CmdEntry, CHAR16 *CmdInput)
{
  UINT32 NVAddr;
  UINT32 NVVal;
  INTN   Res;

  /* List all parameters if no addresss */
  if (StrLen(CmdInput) == 0) {
    XTNVP_LISTALL();
    return 0;
  }

  /* Get parameter address */
  Res = XTParseU32(CmdInput, &NVAddr);
  if (Res < 0) {
    Print(L"Invalid argument - param\r\n");
    return EFI_INVALID_PARAMETER;
  }
  CmdInput += Res;

  /* Validate the address - address is multiple of 8 bytes */
  if (NVAddr % 8 || (NVAddr >= NV_PARAM_MAX_SIZE)) {
    Print(L"Invalid argument - param offset\r\n");
    return EFI_INVALID_PARAMETER;
  }

  /* Get parameter value */
  Res = XTParseU32(CmdInput, &NVVal);
  if (Res < 0) {
    /* Read request */
    Res = NVParamGet(NVAddr, NV_PERM_MANU, &NVVal);
    switch (Res) {
    case EFI_NOT_FOUND:
    case EFI_INVALID_PARAMETER:
    case EFI_UNSUPPORTED:
      Print(L"Non-volatile parameter not set/available\r\n");
      return EFI_SUCCESS;
    case EFI_ACCESS_DENIED:
      Print(L"Non-volatile parameter access denied\r\n");
      return EFI_SUCCESS;
    }
    Print(L"0x%08X\r\n", NVVal);
    return EFI_SUCCESS;
  }
  /* Write request */
  Res = NVParamSet(NVAddr, NV_PERM_BIOS | NV_PERM_MANU | NV_PERM_BMC,
                    NV_PERM_BIOS | NV_PERM_MANU | NV_PERM_BMC, (UINT32) NVVal);
  switch (Res) {
  case EFI_NOT_FOUND:
  case EFI_INVALID_PARAMETER:
  case EFI_UNSUPPORTED:
    Print(L"Non-volatile parameter not set/available\r\n");
    return EFI_SUCCESS;
  case EFI_ACCESS_DENIED:
    Print(L"Non-volatile parameter access denied\r\n");
    return EFI_SUCCESS;
  }
  return EFI_SUCCESS;
}

STATIC UINT64 SMproSetCfg(UINT8 cfg_type, UINT32 val)
{
  ARM_SMC_ARGS SmcArgs;
  #define SMC_PLATFORMINFO_FUNC_ID      0xc300ff02
  #define SMPRO_FUNC_SET_CFG            6

  SmcArgs.Arg0 = SMC_PLATFORMINFO_FUNC_ID;
  SmcArgs.Arg1 = SMPRO_FUNC_SET_CFG;
  SmcArgs.Arg2 = cfg_type;
  SmcArgs.Arg3 = val;

  ArmCallSmc(&SmcArgs);
  if (!SmcArgs.Arg0) {
    return SmcArgs.Arg1;
  }

  return 0;
}

STATIC INTN XTSMpro(CMD_ENTRY *CmdEntry, CHAR16 *CmdInput)
{
  UINT32 CfgType;
  UINT32 CfgValue;
  INTN   Res;

  /* Get parameter address */
  Res = XTParseU32(CmdInput, &CfgType);
  if (Res < 0) {
    Print(L"Invalid argument - cfg\r\n");
    return EFI_INVALID_PARAMETER;
  }
  CmdInput += Res;

  /* Get parameter value */
  Res = XTParseU32(CmdInput, &CfgValue);
  if (Res < 0) {
    Print(L"Invalid argument - value\r\n");
    return EFI_INVALID_PARAMETER;
  }
  Res = SMproSetCfg(CfgType, CfgValue);
  if (Res != 0) {
    Print(L"Unable to set configuration type %d\r\n", CfgType);
    return 0;
  }
  return 0;
}

STATIC CMD_ENTRY CommandTable[] = {
  { L"exit", NULL, L"Exit Ampere tools" },
  { L"help", XTHelp, L"List supported commands" },
  { L"?", XTHelp, L"List supported commands" },
  { L"csr", XTCSR, L"Read/Write CSR register - csr <addr> <rd|wr> <value>"},
  { L"i2cproxy", XTI2CProxy,
                 L"I2C over SMpro/PMpro - i2cproxy <bus> <device addr (hex)> "
                 L"<offset (hex)> <proto> <rd/wr> <length | value (hex)"},
  { L"nvp", XTNVP, L"Set/display non-volatile parameters - nvp <param> <value>\r\n"
                   L"      List all set parameters if no value is given."},
  { L"smpro", XTSMpro, L"Configure SMpro run-time setting - smpro <cfg> <value>" },
  { NULL, NULL, NULL },
};
