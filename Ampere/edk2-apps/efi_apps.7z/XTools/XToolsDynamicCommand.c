 /**
 *
 * Copyright (c) 2019, Ampere Computing LLC
 *
 *  This program and the accompanying materials
 *  are licensed and made available under the terms and conditions of the BSD License
 *  which accompanies this distribution.  The full text of the license may be found at
 *  http://opensource.org/licenses/bsd-license.php
 *
 *  THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.
 *
 **/

#include "XTools.h"
#include <Protocol/ShellDynamicCommand.h>

/**
  This is the shell command handler function pointer callback type.  This
  function handles the command when it is invoked in the shell.

  @param[in] This                   The instance of the EFI_SHELL_DYNAMIC_COMMAND_PROTOCOL.
  @param[in] SystemTable            The pointer to the system table.
  @param[in] ShellParameters        The parameters associated with the command.
  @param[in] Shell                  The instance of the shell protocol used in the context
                                    of processing this command.

  @return EFI_SUCCESS               the operation was sucessful
  @return other                     the operation failed.
**/
SHELL_STATUS
EFIAPI
XToolsCommandHandler (
  IN EFI_SHELL_DYNAMIC_COMMAND_PROTOCOL    *This,
  IN EFI_SYSTEM_TABLE                      *SystemTable,
  IN EFI_SHELL_PARAMETERS_PROTOCOL         *ShellParameters,
  IN EFI_SHELL_PROTOCOL                    *Shell
  )
{
  gEfiShellParametersProtocol = ShellParameters;
  gEfiShellProtocol           = Shell;

  return XToolsEntryPoint (gImageHandle, SystemTable);
}

/**
  This is the command help handler function pointer callback type.  This
  function is responsible for displaying help information for the associated
  command.

  @param[in] This                   The instance of the EFI_SHELL_DYNAMIC_COMMAND_PROTOCOL.
  @param[in] Language               The pointer to the language string to use.

  @return string                    Pool allocated help string, must be freed by caller
**/
CHAR16 *
EFIAPI
XToolsCommandGetHelp (
  IN EFI_SHELL_DYNAMIC_COMMAND_PROTOCOL    *This,
  IN CONST CHAR8                           *Language
  )
{
  CHAR16 *Str, *Str1;

  Str = XToolsGetHelpString ();
  Str1 = CatSPrint(NULL, L".TH xtools 0 \"Set/Modify the platform configuration.\"\r\n"
                        ".SH NAME\r\n"
                        "Set/Modify the platform configuration.\r\n"
                        ".SH SYNOPSIS\r\n"
                        "\r\n%s", Str);
  FreePool (Str);

  return Str1;
}

EFI_SHELL_DYNAMIC_COMMAND_PROTOCOL mXToolsDynamicCommand = {
  L"xtools",
  XToolsCommandHandler,
  XToolsCommandGetHelp
};

/**
  Entry point of XTools Dynamic Command.
  Produce the DynamicCommand protocol to handle "XTools" command.

  @param  ImageHandle            The image handle of the process.
  @param  SystemTable            The EFI System Table pointer.

  @retval EFI_SUCCESS           XTools command is executed sucessfully.
  @retval EFI_ABORTED           HII package was failed to initialize.
  @retval others                Other errors when executing XTools command.
**/
EFI_STATUS
EFIAPI
XToolsCommandInitialize (
  IN EFI_HANDLE               ImageHandle,
  IN EFI_SYSTEM_TABLE         *SystemTable
  )
{
  EFI_STATUS                  Status;

  Status = gBS->InstallProtocolInterface (
                  &ImageHandle,
                  &gEfiShellDynamicCommandProtocolGuid,
                  EFI_NATIVE_INTERFACE,
                  &mXToolsDynamicCommand
                  );
  ASSERT_EFI_ERROR (Status);
  return Status;
}

/**
  XTools driver unload handler.

  @param  ImageHandle           The image handle of the process.

  @retval EFI_SUCCESS           The image is unloaded.
  @retval Others                Failed to unload the image.
**/
EFI_STATUS
EFIAPI
XToolsUnload (
  IN EFI_HANDLE               ImageHandle
)
{
  EFI_STATUS                  Status;
  Status = gBS->UninstallProtocolInterface (
                  ImageHandle,
                  &gEfiShellDynamicCommandProtocolGuid,
                  &mXToolsDynamicCommand
                  );
  if (EFI_ERROR (Status)) {
    return Status;
  }

  return EFI_SUCCESS;
}